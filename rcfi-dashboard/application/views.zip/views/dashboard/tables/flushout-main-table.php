<div class="table-responsive">
  <table id="multi-filter-select2" class="display table table-striped table-hover" >
    <thead>
      <tr>
        <th>Account</th>
        <!-- <th>GC</th> -->
        <th>Pairing</th>
        <th>Flushout</th>
      </tr>
    </thead>
    <tbody id="table_tbody_for_append">
     
    </tbody>
  </table>
</div>