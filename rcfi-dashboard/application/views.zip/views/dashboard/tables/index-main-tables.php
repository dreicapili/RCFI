<div class="table-responsive">
  <table id="multi-filter-select2" class="display table table-striped table-hover" >
    <thead>
      <tr>
        <th>Reference #</th>
        <th>Name</th>
        <th>Account Flushout</th>
        <th>Account Income</th>
      </tr>
    </thead>
    <tbody>
      
    </tbody>
  </table>
</div>