/**
 * Title:   Dashcore - HTML App Landing Page - Main Javascript file
 * Author:  http://themeforest.net/user/5studiosnet
 **/

(function() {
    'use strict';

    $('[data-toggle="tooltip"]').tooltip();
});